# gincana
Para a gincana proposta dia 10/04/2025. Montar 7 sites de empresas diferentes seguindo os requisitos impostos
